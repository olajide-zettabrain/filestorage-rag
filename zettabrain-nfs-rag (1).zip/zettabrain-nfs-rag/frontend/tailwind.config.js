/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        zetta: {
          orange: '#FF8C42',
          'orange-light': '#FFB380',
          'orange-dark': '#E67829',
          gray: '#3D3D3D',
          'gray-light': '#666666',
          'gray-dark': '#1A1A1A',
        },
        primary: {
          50: '#FFF4ED',
          100: '#FFE8D6',
          200: '#FFCCAC',
          300: '#FFB380',
          400: '#FF8C42',
          500: '#E67829',
          600: '#CC6722',
          700: '#B3581D',
          800: '#994A18',
          900: '#803D13',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
