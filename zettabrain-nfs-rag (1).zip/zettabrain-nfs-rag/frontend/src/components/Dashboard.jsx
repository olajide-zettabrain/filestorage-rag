import React from 'react';
import { 
  ServerIcon, 
  DocumentTextIcon, 
  CircleStackIcon,
  CpuChipIcon,
  ChartBarIcon 
} from '@heroicons/react/24/outline';

export default function Dashboard({ serverStatus }) {
  if (!serverStatus) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-zetta-orange"></div>
      </div>
    );
  }

  const stats = [
    {
      name: 'NFS Server Status',
      value: serverStatus.nfs_server_running ? 'Running' : 'Stopped',
      icon: ServerIcon,
      color: serverStatus.nfs_server_running ? 'text-green-600' : 'text-red-600',
      bg: serverStatus.nfs_server_running ? 'bg-green-100' : 'bg-red-100',
    },
    {
      name: 'Total Documents',
      value: serverStatus.total_documents,
      icon: DocumentTextIcon,
      color: 'text-blue-600',
      bg: 'bg-blue-100',
    },
    {
      name: 'Indexed Documents',
      value: serverStatus.indexed_documents,
      icon: CircleStackIcon,
      color: 'text-purple-600',
      bg: 'bg-purple-100',
    },
    {
      name: 'Active Connections',
      value: serverStatus.active_connections,
      icon: ChartBarIcon,
      color: 'text-orange-600',
      bg: 'bg-orange-100',
    },
  ];

  const resources = [
    {
      name: 'CPU Usage',
      value: serverStatus.cpu_percent,
      max: 100,
      color: 'bg-zetta-orange',
    },
    {
      name: 'Memory Usage',
      value: serverStatus.memory_percent,
      max: 100,
      color: 'bg-blue-500',
    },
    {
      name: 'Disk Usage',
      value: serverStatus.disk_percent,
      max: 100,
      color: 'bg-purple-500',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="mt-2 text-gray-600">
          Welcome to ZettaBrain NFS-RAG Platform
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.name} className="card">
            <div className="flex items-center">
              <div className={`${stat.bg} ${stat.color} p-3 rounded-lg`}>
                <stat.icon className="h-6 w-6" />
              </div>
              <div className="ml-4 flex-1">
                <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Resource Usage */}
      <div className="card">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">
          System Resources
        </h2>
        <div className="space-y-6">
          {resources.map((resource) => (
            <div key={resource.name}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">
                  {resource.name}
                </span>
                <span className="text-sm font-bold text-gray-900">
                  {resource.value.toFixed(1)}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className={`${resource.color} h-2.5 rounded-full transition-all duration-500`}
                  style={{ width: `${resource.value}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Quick Actions
          </h3>
          <div className="space-y-3">
            <button className="w-full btn-primary text-left">
              Upload New Document
            </button>
            <button className="w-full btn-secondary text-left">
              Create NFS Share
            </button>
            <button className="w-full btn-secondary text-left">
              Run RAG Query
            </button>
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            System Information
          </h3>
          <dl className="space-y-3">
            <div className="flex justify-between">
              <dt className="text-sm text-gray-600">NFS Shares</dt>
              <dd className="text-sm font-medium text-gray-900">
                {serverStatus.total_shares}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm text-gray-600">Indexed Documents</dt>
              <dd className="text-sm font-medium text-gray-900">
                {serverStatus.indexed_documents}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm text-gray-600">Active Clients</dt>
              <dd className="text-sm font-medium text-gray-900">
                {serverStatus.active_connections}
              </dd>
            </div>
          </dl>
        </div>
      </div>
    </div>
  );
}
