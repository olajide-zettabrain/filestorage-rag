import React, { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import { 
  PlusIcon, 
  TrashIcon, 
  PencilIcon,
  PlayIcon,
  StopIcon,
  ArrowPathIcon 
} from '@heroicons/react/24/outline';

export default function NFSManager() {
  const [shares, setShares] = useState([]);
  const [nfsStatus, setNfsStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [sharesRes, statusRes] = await Promise.all([
        fetch('/api/v1/nfs/shares'),
        fetch('/api/v1/nfs/server/status')
      ]);
      
      const sharesData = await sharesRes.json();
      const statusData = await statusRes.json();
      
      setShares(sharesData);
      setNfsStatus(statusData);
    } catch (error) {
      toast.error('Failed to fetch NFS data');
    } finally {
      setLoading(false);
    }
  };

  const handleServerAction = async (action) => {
    try {
      const response = await fetch(`/api/v1/nfs/server/${action}`, {
        method: 'POST'
      });
      
      if (response.ok) {
        toast.success(`NFS server ${action}ed successfully`);
        fetchData();
      } else {
        toast.error(`Failed to ${action} NFS server`);
      }
    } catch (error) {
      toast.error(`Error: ${error.message}`);
    }
  };

  const handleDeleteShare = async (shareId) => {
    if (!confirm('Are you sure you want to delete this share?')) return;

    try {
      const response = await fetch(`/api/v1/nfs/shares/${shareId}`, {
        method: 'DELETE'
      });
      
      if (response.ok) {
        toast.success('Share deleted successfully');
        fetchData();
      } else {
        toast.error('Failed to delete share');
      }
    } catch (error) {
      toast.error(`Error: ${error.message}`);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-zetta-orange"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">NFS Management</h1>
          <p className="mt-2 text-gray-600">Manage your NFS server and shares</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="btn-primary inline-flex items-center"
        >
          <PlusIcon className="h-5 w-5 mr-2" />
          Create Share
        </button>
      </div>

      {/* Server Status */}
      <div className="card">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Server Status</h2>
            <div className="mt-2 flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${
                nfsStatus?.is_running ? 'bg-green-500' : 'bg-red-500'
              }`} />
              <span className="text-gray-700">
                {nfsStatus?.is_running ? 'Running' : 'Stopped'}
              </span>
              <span className="text-gray-500">•</span>
              <span className="text-gray-600">
                {nfsStatus?.active_connections} active connections
              </span>
            </div>
          </div>
          <div className="flex space-x-2">
            {!nfsStatus?.is_running ? (
              <button
                onClick={() => handleServerAction('start')}
                className="btn-primary inline-flex items-center"
              >
                <PlayIcon className="h-4 w-4 mr-2" />
                Start
              </button>
            ) : (
              <>
                <button
                  onClick={() => handleServerAction('restart')}
                  className="btn-secondary inline-flex items-center"
                >
                  <ArrowPathIcon className="h-4 w-4 mr-2" />
                  Restart
                </button>
                <button
                  onClick={() => handleServerAction('stop')}
                  className="btn-danger inline-flex items-center"
                >
                  <StopIcon className="h-4 w-4 mr-2" />
                  Stop
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Shares List */}
      <div className="card">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">NFS Shares</h2>
        
        {shares.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">No NFS shares configured</p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="mt-4 btn-primary"
            >
              Create Your First Share
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Path
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Client
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Size
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {shares.map((share) => (
                  <tr key={share.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {share.name}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-600">{share.path}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-600">{share.client_spec}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {share.is_active ? (
                        <span className="badge badge-success">Active</span>
                      ) : (
                        <span className="badge badge-warning">Inactive</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {(share.total_size_bytes / 1024 / 1024).toFixed(2)} MB
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleDeleteShare(share.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        <TrashIcon className="h-5 w-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create Share Modal */}
      {showCreateModal && (
        <CreateShareModal
          onClose={() => setShowCreateModal(false)}
          onSuccess={() => {
            setShowCreateModal(false);
            fetchData();
          }}
        />
      )}
    </div>
  );
}

function CreateShareModal({ onClose, onSuccess }) {
  const [formData, setFormData] = useState({
    name: '',
    path: '',
    client_spec: '*',
    permissions: 'rw,sync,no_subtree_check',
    description: ''
  });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const response = await fetch('/api/v1/nfs/shares', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        toast.success('Share created successfully');
        onSuccess();
      } else {
        const error = await response.json();
        toast.error(error.detail || 'Failed to create share');
      }
    } catch (error) {
      toast.error(`Error: ${error.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4 p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">
          Create NFS Share
        </h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Share Name
            </label>
            <input
              type="text"
              required
              className="input-field"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Path
            </label>
            <input
              type="text"
              required
              className="input-field"
              value={formData.path}
              onChange={(e) => setFormData({...formData, path: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Client Specification
            </label>
            <input
              type="text"
              className="input-field"
              value={formData.client_spec}
              onChange={(e) => setFormData({...formData, client_spec: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description (Optional)
            </label>
            <textarea
              className="input-field"
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
            />
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary"
              disabled={submitting}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn-primary"
              disabled={submitting}
            >
              {submitting ? 'Creating...' : 'Create Share'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
