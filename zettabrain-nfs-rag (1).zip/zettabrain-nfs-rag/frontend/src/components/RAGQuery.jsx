import React, { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import { 
  ChatBubbleLeftRightIcon,
  PaperAirplaneIcon,
  ClockIcon 
} from '@heroicons/react/24/outline';

export default function RAGQuery() {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);
  const [llmProvider, setLlmProvider] = useState('local');

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const response = await fetch('/api/v1/query/history?limit=10');
      const data = await response.json();
      setHistory(data);
    } catch (error) {
      console.error('Failed to fetch history');
    }
  };

  const handleQuery = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setResult(null);

    try {
      const response = await fetch('/api/v1/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: query.trim(),
          top_k: 5,
          use_llm: true,
          llm_provider: llmProvider === 'local' ? null : llmProvider
        })
      });

      if (response.ok) {
        const data = await response.json();
        setResult(data);
        fetchHistory();
      } else {
        toast.error('Query failed');
      }
    } catch (error) {
      toast.error(`Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">RAG Query</h1>
        <p className="mt-2 text-gray-600">Ask questions about your documents</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Query Interface */}
        <div className="lg:col-span-2 space-y-6">
          <div className="card">
            <form onSubmit={handleQuery} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your Question
                </label>
                <textarea
                  className="input-field"
                  rows={4}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Ask anything about your documents..."
                  disabled={loading}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    LLM Provider
                  </label>
                  <select
                    className="input-field w-48"
                    value={llmProvider}
                    onChange={(e) => setLlmProvider(e.target.value)}
                    disabled={loading}
                  >
                    <option value="local">Local (Lightweight)</option>
                    <option value="anthropic">Claude Sonnet</option>
                    <option value="openai">GPT-4</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="btn-primary inline-flex items-center"
                  disabled={loading || !query.trim()}
                >
                  {loading ? (
                    <>
                      <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <PaperAirplaneIcon className="h-5 w-5 mr-2" />
                      Ask Question
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Results */}
          {result && (
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Response</h3>
              <div className="prose max-w-none">
                <p className="text-gray-700 whitespace-pre-wrap">{result.response}</p>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                  <span>Retrieved {result.retrieved_documents} documents</span>
                  <span>Total time: {result.total_time_ms.toFixed(0)}ms</span>
                </div>

                <h4 className="font-medium text-gray-900 mb-3">Source Documents</h4>
                <div className="space-y-2">
                  {result.documents.map((doc, idx) => (
                    <div key={idx} className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-700 line-clamp-3">{doc.text}</p>
                      <div className="mt-2 text-xs text-gray-500">
                        Source: {doc.metadata.filename || 'Unknown'}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* History Sidebar */}
        <div className="card h-fit">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Queries</h3>
          {history.length === 0 ? (
            <p className="text-sm text-gray-500">No queries yet</p>
          ) : (
            <div className="space-y-3">
              {history.map((item) => (
                <div
                  key={item.id}
                  className="p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                  onClick={() => setQuery(item.query)}
                >
                  <p className="text-sm text-gray-700 line-clamp-2">{item.query}</p>
                  <div className="mt-2 flex items-center text-xs text-gray-500">
                    <ClockIcon className="h-3 w-3 mr-1" />
                    {new Date(item.created_at).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
