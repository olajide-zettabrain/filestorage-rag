import React, { useState } from 'react';
import { toast } from 'react-hot-toast';

export default function Settings() {
  const [config, setConfig] = useState({
    vectorDB: 'chroma',
    llmProvider: 'local',
    anthropicKey: '',
    openaiKey: '',
    pineconeKey: ''
  });

  const handleSave = () => {
    toast.success('Settings saved successfully');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="mt-2 text-gray-600">Configure your ZettaBrain platform</p>
      </div>

      <div className="card space-y-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Vector Database</h3>
          <select className="input-field" value={config.vectorDB} onChange={(e) => setConfig({...config, vectorDB: e.target.value})}>
            <option value="chroma">ChromaDB (Lightweight)</option>
            <option value="faiss">FAISS (Lightweight)</option>
            <option value="pinecone">Pinecone (Production)</option>
            <option value="qdrant">Qdrant (Production)</option>
            <option value="weaviate">Weaviate (Production)</option>
          </select>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">LLM Provider</h3>
          <select className="input-field" value={config.llmProvider} onChange={(e) => setConfig({...config, llmProvider: e.target.value})}>
            <option value="local">Local (Lightweight)</option>
            <option value="anthropic">Anthropic Claude</option>
            <option value="openai">OpenAI GPT</option>
          </select>
        </div>

        {config.llmProvider === 'anthropic' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Anthropic API Key</label>
            <input
              type="password"
              className="input-field"
              value={config.anthropicKey}
              onChange={(e) => setConfig({...config, anthropicKey: e.target.value})}
              placeholder="sk-ant-..."
            />
          </div>
        )}

        {config.llmProvider === 'openai' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">OpenAI API Key</label>
            <input
              type="password"
              className="input-field"
              value={config.openaiKey}
              onChange={(e) => setConfig({...config, openaiKey: e.target.value})}
              placeholder="sk-..."
            />
          </div>
        )}

        {config.vectorDB === 'pinecone' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Pinecone API Key</label>
            <input
              type="password"
              className="input-field"
              value={config.pineconeKey}
              onChange={(e) => setConfig({...config, pineconeKey: e.target.value})}
            />
          </div>
        )}

        <div className="flex justify-end">
          <button onClick={handleSave} className="btn-primary">Save Settings</button>
        </div>
      </div>
    </div>
  );
}
