import React, { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import { 
  DocumentTextIcon,
  CloudArrowUpIcon,
  TrashIcon,
  MagnifyingGlassIcon 
} from '@heroicons/react/24/outline';

export default function DocumentManager() {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchDocuments();
    const interval = setInterval(fetchDocuments, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchDocuments = async () => {
    try {
      const response = await fetch('/api/v1/documents');
      const data = await response.json();
      setDocuments(data);
    } catch (error) {
      console.error('Failed to fetch documents');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/v1/documents/upload', {
        method: 'POST',
        body: formData
      });

      if (response.ok) {
        toast.success('Document uploaded successfully');
        fetchDocuments();
      } else {
        toast.error('Failed to upload document');
      }
    } catch (error) {
      toast.error(`Error: ${error.message}`);
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this document?')) return;

    try {
      const response = await fetch(`/api/v1/documents/${id}`, {
        method: 'DELETE'
      });
      
      if (response.ok) {
        toast.success('Document deleted');
        fetchDocuments();
      }
    } catch (error) {
      toast.error('Failed to delete document');
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      completed: 'badge-success',
      processing: 'badge-warning',
      pending: 'badge-info',
      failed: 'badge-error'
    };
    return badges[status] || 'badge-info';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Document Manager</h1>
          <p className="mt-2 text-gray-600">Upload and manage documents for RAG</p>
        </div>
        <label className="btn-primary inline-flex items-center cursor-pointer">
          <CloudArrowUpIcon className="h-5 w-5 mr-2" />
          {uploading ? 'Uploading...' : 'Upload Document'}
          <input
            type="file"
            className="hidden"
            onChange={handleFileUpload}
            disabled={uploading}
            accept=".pdf,.docx,.txt,.md,.pptx,.xlsx"
          />
        </label>
      </div>

      <div className="card">
        <div className="mb-4 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-900">Documents</h2>
          <span className="text-sm text-gray-600">{documents.length} total</span>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-zetta-orange mx-auto"></div>
          </div>
        ) : documents.length === 0 ? (
          <div className="text-center py-12">
            <DocumentTextIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No documents uploaded yet</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {documents.map((doc) => (
              <div key={doc.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <DocumentTextIcon className="h-8 w-8 text-zetta-orange" />
                  <span className={`badge ${getStatusBadge(doc.processing_status)}`}>
                    {doc.processing_status}
                  </span>
                </div>
                <h3 className="mt-3 font-medium text-gray-900 truncate" title={doc.filename}>
                  {doc.filename}
                </h3>
                <p className="mt-1 text-sm text-gray-600">
                  {(doc.file_size_bytes / 1024).toFixed(2)} KB
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  {doc.chunk_count || 0} chunks indexed
                </p>
                <div className="mt-4 flex justify-end">
                  <button
                    onClick={() => handleDelete(doc.id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <TrashIcon className="h-5 w-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
