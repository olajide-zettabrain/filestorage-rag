import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { 
  HomeIcon, 
  ServerIcon, 
  DocumentTextIcon, 
  ChatBubbleLeftRightIcon,
  ChartBarIcon,
  Cog6ToothIcon 
} from '@heroicons/react/24/outline';

// Import components (we'll create these)
import Dashboard from './components/Dashboard';
import NFSManager from './components/NFSManager';
import DocumentManager from './components/DocumentManager';
import RAGQuery from './components/RAGQuery';
import Analytics from './components/Analytics';
import Settings from './components/Settings';

function App() {
  const [serverStatus, setServerStatus] = useState(null);

  useEffect(() => {
    fetchServerStatus();
    const interval = setInterval(fetchServerStatus, 30000); // Every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchServerStatus = async () => {
    try {
      const response = await fetch('/api/v1/status');
      const data = await response.json();
      setServerStatus(data);
    } catch (error) {
      console.error('Failed to fetch server status:', error);
    }
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Toaster position="top-right" />
        
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              {/* Logo */}
              <div className="flex items-center space-x-4">
                <img 
                  src="/zetabrain_logo.png" 
                  alt="ZettaBrain" 
                  className="h-8 w-auto"
                />
              </div>

              {/* Status Indicator */}
              {serverStatus && (
                <div className="flex items-center space-x-6">
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${
                      serverStatus.nfs_server_running ? 'bg-green-500' : 'bg-red-500'
                    }`} />
                    <span className="text-sm text-gray-600">
                      NFS {serverStatus.nfs_server_running ? 'Online' : 'Offline'}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600">
                    {serverStatus.total_documents} Documents
                  </div>
                  <div className="text-sm text-gray-600">
                    CPU: {serverStatus.cpu_percent.toFixed(1)}%
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        <div className="flex">
          {/* Sidebar */}
          <Sidebar />

          {/* Main Content */}
          <main className="flex-1 p-8">
            <Routes>
              <Route path="/" element={<Dashboard serverStatus={serverStatus} />} />
              <Route path="/nfs" element={<NFSManager />} />
              <Route path="/documents" element={<DocumentManager />} />
              <Route path="/query" element={<RAGQuery />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  );
}

function Sidebar() {
  const location = useLocation();
  
  const navigation = [
    { name: 'Dashboard', path: '/', icon: HomeIcon },
    { name: 'NFS Management', path: '/nfs', icon: ServerIcon },
    { name: 'Documents', path: '/documents', icon: DocumentTextIcon },
    { name: 'RAG Query', path: '/query', icon: ChatBubbleLeftRightIcon },
    { name: 'Analytics', path: '/analytics', icon: ChartBarIcon },
    { name: 'Settings', path: '/settings', icon: Cog6ToothIcon },
  ];

  return (
    <aside className="w-64 bg-white border-r border-gray-200 min-h-[calc(100vh-4rem)] sticky top-16">
      <nav className="p-4 space-y-1">
        {navigation.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.name}
              to={item.path}
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors duration-200 ${
                isActive
                  ? 'bg-zetta-orange text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <item.icon className="h-5 w-5" />
              <span className="font-medium">{item.name}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}

export default App;
