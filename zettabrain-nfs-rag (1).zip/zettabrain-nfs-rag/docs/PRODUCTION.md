# ZettaBrain Production Deployment Guide

This guide covers deploying ZettaBrain NFS-RAG Platform in a production environment.

## 🏭 Production Checklist

### 1. Infrastructure Requirements

**Minimum Specifications:**
- CPU: 4 cores
- RAM: 8GB
- Storage: 100GB SSD
- OS: Ubuntu 20.04+ or similar Linux distribution

**Recommended Specifications:**
- CPU: 8+ cores
- RAM: 16GB+
- Storage: 500GB+ SSD
- OS: Ubuntu 22.04 LTS
- GPU: Optional, for faster local LLM inference

### 2. Security Configuration

#### Update Secret Key
```bash
# Generate a secure secret key
python -c "import secrets; print(secrets.token_urlsafe(32))"

# Update in .env
SECRET_KEY=your-generated-secret-key
```

#### Configure CORS
```bash
# In .env, set allowed origins
ALLOWED_ORIGINS=["https://yourdomain.com"]
```

#### Database Security
```bash
# Use strong passwords
POSTGRES_PASSWORD=<strong-random-password>

# Restrict database access
# Edit docker compose.yml to not expose PostgreSQL port externally
```

#### SSL/TLS Setup
```bash
# Use nginx or traefik as reverse proxy
# Example nginx configuration:

server {
    listen 443 ssl;
    server_name zettabrain.yourdomain.com;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### 3. Production Environment Configuration

#### Use Production Vector Database

**Option 1: Pinecone**
```bash
VECTOR_DB_TYPE=pinecone
PINECONE_API_KEY=your-api-key
PINECONE_ENVIRONMENT=us-west1-gcp
PINECONE_INDEX_NAME=zettabrain-prod
```

**Option 2: Qdrant (Self-hosted)**
```bash
VECTOR_DB_TYPE=qdrant
QDRANT_URL=http://qdrant:6333
QDRANT_COLLECTION_NAME=zettabrain_docs
```

**Option 3: Weaviate (Self-hosted)**
```bash
VECTOR_DB_TYPE=weaviate
WEAVIATE_URL=http://weaviate:8080
WEAVIATE_CLASS_NAME=ZettaBrainDoc
```

#### Use Production LLM

**Anthropic Claude (Recommended)**
```bash
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=your-api-key
ANTHROPIC_MODEL=claude-sonnet-4-20250514
```

**OpenAI GPT**
```bash
LLM_PROVIDER=openai
OPENAI_API_KEY=your-api-key
OPENAI_MODEL=gpt-4-turbo-preview
```

### 4. Database Backups

#### Automated PostgreSQL Backups
```bash
# Create backup script
cat > backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/backups/postgres"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR

docker exec zettabrain-postgres pg_dump -U zettabrain zettabrain | gzip > $BACKUP_DIR/backup_$DATE.sql.gz

# Keep only last 7 days
find $BACKUP_DIR -name "backup_*.sql.gz" -mtime +7 -delete
EOF

chmod +x backup.sh

# Add to crontab for daily backups at 2 AM
crontab -e
# Add: 0 2 * * * /path/to/backup.sh
```

#### Backup Vector Database
```bash
# For ChromaDB/FAISS (local)
tar -czf vector_db_backup.tar.gz /mnt/nfs/vector_db/

# For Pinecone/Qdrant/Weaviate
# Use their respective backup tools or APIs
```

### 5. Monitoring Setup

#### Prometheus Metrics
```yaml
# Add to docker compose.yml
prometheus:
  image: prom/prometheus
  ports:
    - "9090:9090"
  volumes:
    - ./prometheus.yml:/etc/prometheus/prometheus.yml
    - prometheus_data:/prometheus
  networks:
    - zettabrain-network
```

#### Grafana Dashboard
```yaml
grafana:
  image: grafana/grafana
  ports:
    - "3001:3000"
  environment:
    - GF_SECURITY_ADMIN_PASSWORD=admin
  volumes:
    - grafana_data:/var/lib/grafana
  networks:
    - zettabrain-network
```

### 6. Logging

#### Centralized Logging
```yaml
# Add to docker compose.yml
loki:
  image: grafana/loki
  ports:
    - "3100:3100"
  volumes:
    - loki_data:/loki
  networks:
    - zettabrain-network

promtail:
  image: grafana/promtail
  volumes:
    - /var/log:/var/log
    - ./promtail-config.yml:/etc/promtail/config.yml
  networks:
    - zettabrain-network
```

### 7. Performance Optimization

#### Database Connection Pool
```python
# In config.py
engine = create_async_engine(
    settings.DATABASE_URL,
    pool_size=20,  # Increase for production
    max_overflow=40,
    pool_pre_ping=True,
    pool_recycle=3600
)
```

#### Redis Caching
```python
# Enable aggressive caching
REDIS_CACHE_TTL=3600
ENABLE_QUERY_CACHE=True
```

#### Worker Configuration
```bash
# In .env
WORKERS=8  # 2x CPU cores
```

### 8. Scaling

#### Horizontal Scaling
```yaml
# docker compose.yml
backend:
  deploy:
    replicas: 3
  # Add load balancer
```

#### Database Replication
```yaml
postgres-replica:
  image: postgres:16-alpine
  environment:
    POSTGRES_MASTER_SERVICE_HOST: postgres
  # Configure streaming replication
```

### 9. Health Checks

#### Application Health
```bash
# Test backend health
curl http://localhost:8000/health

# Test database connection
curl http://localhost:8000/api/v1/status
```

#### Monitoring Script
```bash
#!/bin/bash
# health_check.sh
if ! curl -f http://localhost:8000/health > /dev/null 2>&1; then
    echo "Backend unhealthy, restarting..."
    docker compose restart backend
fi
```

### 10. Disaster Recovery

#### Recovery Procedure
```bash
# 1. Restore database
gunzip -c backup_20240124.sql.gz | docker exec -i zettabrain-postgres psql -U zettabrain zettabrain

# 2. Restore vector database
tar -xzf vector_db_backup.tar.gz -C /

# 3. Restart services
docker compose down
docker compose up -d
```

## 🚀 Deployment Steps

### Step 1: Prepare Server
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker compose
sudo chmod +x /usr/local/bin/docker compose
```

### Step 2: Deploy Application
```bash
# Clone repository
git clone <your-repo>
cd zettabrain-nfs-rag

# Configure environment
cp .env.example .env
nano .env  # Edit with production values

# Build and start
docker compose -f docker compose.prod.yml up -d
```

### Step 3: Verify Deployment
```bash
# Check service status
docker compose ps

# Check logs
docker compose logs -f

# Test endpoints
curl http://localhost:8000/health
```

### Step 4: Configure Monitoring
```bash
# Set up monitoring alerts
# Configure backup cron jobs
# Set up log rotation
```

## 📊 Performance Benchmarks

### Expected Performance

**Lightweight Configuration:**
- Document indexing: ~10 docs/minute
- Query latency: ~500ms
- Memory usage: ~2GB

**Production Configuration:**
- Document indexing: ~50 docs/minute
- Query latency: ~200ms
- Memory usage: ~8GB

## 🔧 Maintenance

### Regular Tasks

**Daily:**
- Monitor error logs
- Check disk space
- Verify backups

**Weekly:**
- Review performance metrics
- Update dependencies
- Clean old logs

**Monthly:**
- Security updates
- Capacity planning
- Performance tuning

## 📞 Production Support

For production issues:
- Check logs: `docker compose logs -f backend`
- Review metrics: http://localhost:9090
- Contact support: support@zettabrain.com

## 🎯 Best Practices

1. Always use SSL/TLS in production
2. Enable authentication for all endpoints
3. Regular security audits
4. Monitor resource usage
5. Test disaster recovery procedures
6. Keep documentation updated
7. Implement rate limiting
8. Use environment-specific configurations
9. Regular backups (automated)
10. Monitor third-party API costs (Anthropic, OpenAI, Pinecone)

---

For additional help, see the main README.md or contact support.
