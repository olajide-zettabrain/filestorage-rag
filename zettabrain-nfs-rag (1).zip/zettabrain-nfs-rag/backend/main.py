"""
ZettaBrain NFS-RAG Platform - Main Application
Production-ready FastAPI application for NFS management and RAG
"""
from fastapi import FastAPI, HTTPException, UploadFile, File, Depends, BackgroundTasks, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional
from datetime import datetime
import aiofiles
from pathlib import Path
import uuid
import shutil

from pydantic import BaseModel, Field

# Local imports
from config import settings, init_directories
from models import (
    Base, NFSShare, Document, DocumentChunk, QueryLog, User,
    SystemMetrics, get_db, init_db
)
from nfs_manager import nfs_manager
from rag_engine import rag_engine

# Initialize FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Production-ready NFS Server Management with integrated RAG platform"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================================
# Pydantic Models
# ============================================================================

class NFSShareCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    path: str = Field(..., min_length=1)
    client_spec: str = Field(default="*")
    permissions: str = Field(default="rw,sync,no_subtree_check")
    description: Optional[str] = None


class NFSShareUpdate(BaseModel):
    client_spec: Optional[str] = None
    permissions: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None


class NFSShareResponse(BaseModel):
    id: int
    name: str
    path: str
    client_spec: str
    permissions: str
    is_active: bool
    description: Optional[str]
    total_size_bytes: int
    file_count: int
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


class DocumentUploadResponse(BaseModel):
    id: int
    filename: str
    file_size_bytes: int
    processing_status: str
    message: str


class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1)
    top_k: int = Field(default=5, ge=1, le=20)
    use_llm: bool = Field(default=True)
    llm_provider: Optional[str] = Field(default=None)
    nfs_share_id: Optional[int] = None


class QueryResponse(BaseModel):
    query: str
    response: Optional[str]
    retrieved_documents: int
    documents: List[dict]
    retrieval_time_ms: float
    llm_time_ms: Optional[float]
    total_time_ms: float


class SystemStatus(BaseModel):
    nfs_server_running: bool
    active_connections: int
    total_shares: int
    total_documents: int
    indexed_documents: int
    cpu_percent: float
    memory_percent: float
    disk_percent: float


# ============================================================================
# Startup/Shutdown Events
# ============================================================================

@app.on_event("startup")
async def startup_event():
    """Initialize application on startup"""
    print("=" * 60)
    print(f"Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    print("=" * 60)
    
    # Initialize directories
    init_directories()
    
    # Initialize database
    await init_db()
    
    print("✓ Application started successfully")
    print(f"✓ NFS Base Path: {settings.NFS_BASE_PATH}")
    print(f"✓ RAG Storage: {settings.RAG_STORAGE_PATH}")
    print(f"✓ Vector DB: {settings.VECTOR_DB_TYPE}")
    print(f"✓ LLM Provider: {settings.LLM_PROVIDER}")
    print("=" * 60)


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    print("Shutting down application...")


# ============================================================================
# Health & Status Endpoints
# ============================================================================

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}


@app.get("/api/v1/status", response_model=SystemStatus)
async def get_system_status(db: AsyncSession = Depends(get_db)):
    """Get comprehensive system status"""
    # NFS status
    nfs_status = await nfs_manager.get_nfs_server_status()
    system_stats = await nfs_manager.get_system_stats()
    
    # Database stats
    shares_count = await db.scalar(select(func.count(NFSShare.id)))
    docs_count = await db.scalar(select(func.count(Document.id)))
    indexed_count = await db.scalar(
        select(func.count(Document.id)).where(Document.is_indexed == True)
    )
    
    return SystemStatus(
        nfs_server_running=nfs_status["is_running"],
        active_connections=nfs_status["active_connections"],
        total_shares=shares_count or 0,
        total_documents=docs_count or 0,
        indexed_documents=indexed_count or 0,
        cpu_percent=system_stats["cpu_percent"],
        memory_percent=system_stats["memory_percent"],
        disk_percent=system_stats["disk_percent"]
    )


# ============================================================================
# NFS Management Endpoints
# ============================================================================

@app.get("/api/v1/nfs/server/status")
async def nfs_server_status():
    """Get NFS server status"""
    return await nfs_manager.get_nfs_server_status()


@app.post("/api/v1/nfs/server/start")
async def start_nfs_server():
    """Start NFS server"""
    success = await nfs_manager.start_nfs_server()
    if success:
        return {"message": "NFS server started successfully"}
    raise HTTPException(status_code=500, detail="Failed to start NFS server")


@app.post("/api/v1/nfs/server/stop")
async def stop_nfs_server():
    """Stop NFS server"""
    success = await nfs_manager.stop_nfs_server()
    if success:
        return {"message": "NFS server stopped successfully"}
    raise HTTPException(status_code=500, detail="Failed to stop NFS server")


@app.post("/api/v1/nfs/server/restart")
async def restart_nfs_server():
    """Restart NFS server"""
    success = await nfs_manager.restart_nfs_server()
    if success:
        return {"message": "NFS server restarted successfully"}
    raise HTTPException(status_code=500, detail="Failed to restart NFS server")


@app.get("/api/v1/nfs/shares", response_model=List[NFSShareResponse])
async def list_nfs_shares(
    skip: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db)
):
    """List all NFS shares"""
    result = await db.execute(
        select(NFSShare).offset(skip).limit(limit).order_by(NFSShare.created_at.desc())
    )
    shares = result.scalars().all()
    return shares


@app.post("/api/v1/nfs/shares", response_model=NFSShareResponse)
async def create_nfs_share(
    share: NFSShareCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create new NFS share"""
    # Create share using NFS manager
    success, message = await nfs_manager.create_share(
        share.path,
        share.client_spec,
        share.permissions
    )
    
    if not success:
        raise HTTPException(status_code=400, detail=message)
    
    # Save to database
    db_share = NFSShare(
        name=share.name,
        path=share.path,
        client_spec=share.client_spec,
        permissions=share.permissions,
        description=share.description,
        created_by="system"  # TODO: Add auth
    )
    
    db.add(db_share)
    await db.commit()
    await db.refresh(db_share)
    
    return db_share


@app.get("/api/v1/nfs/shares/{share_id}", response_model=NFSShareResponse)
async def get_nfs_share(share_id: int, db: AsyncSession = Depends(get_db)):
    """Get specific NFS share"""
    result = await db.execute(select(NFSShare).where(NFSShare.id == share_id))
    share = result.scalar_one_or_none()
    
    if not share:
        raise HTTPException(status_code=404, detail="Share not found")
    
    return share


@app.put("/api/v1/nfs/shares/{share_id}", response_model=NFSShareResponse)
async def update_nfs_share(
    share_id: int,
    share_update: NFSShareUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update NFS share"""
    result = await db.execute(select(NFSShare).where(NFSShare.id == share_id))
    share = result.scalar_one_or_none()
    
    if not share:
        raise HTTPException(status_code=404, detail="Share not found")
    
    # Update NFS configuration if needed
    if share_update.client_spec or share_update.permissions:
        success, message = await nfs_manager.update_share(
            share.path,
            share_update.client_spec,
            share_update.permissions
        )
        if not success:
            raise HTTPException(status_code=400, detail=message)
    
    # Update database
    if share_update.client_spec:
        share.client_spec = share_update.client_spec
    if share_update.permissions:
        share.permissions = share_update.permissions
    if share_update.description is not None:
        share.description = share_update.description
    if share_update.is_active is not None:
        share.is_active = share_update.is_active
    
    await db.commit()
    await db.refresh(share)
    
    return share


@app.delete("/api/v1/nfs/shares/{share_id}")
async def delete_nfs_share(
    share_id: int,
    delete_data: bool = Query(False),
    db: AsyncSession = Depends(get_db)
):
    """Delete NFS share"""
    result = await db.execute(select(NFSShare).where(NFSShare.id == share_id))
    share = result.scalar_one_or_none()
    
    if not share:
        raise HTTPException(status_code=404, detail="Share not found")
    
    # Remove from NFS
    success, message = await nfs_manager.remove_share(share.path, delete_data)
    if not success:
        raise HTTPException(status_code=400, detail=message)
    
    # Delete from database
    await db.delete(share)
    await db.commit()
    
    return {"message": "Share deleted successfully"}


@app.get("/api/v1/nfs/clients")
async def list_mounted_clients():
    """List currently mounted NFS clients"""
    return await nfs_manager.get_mounted_clients()


@app.get("/api/v1/nfs/stats")
async def get_nfs_stats():
    """Get NFS server statistics"""
    return await nfs_manager.get_system_stats()


# ============================================================================
# RAG / Document Management Endpoints
# ============================================================================

@app.post("/api/v1/documents/upload", response_model=DocumentUploadResponse)
async def upload_document(
    file: UploadFile = File(...),
    nfs_share_id: Optional[int] = None,
    title: Optional[str] = None,
    description: Optional[str] = None,
    background_tasks: BackgroundTasks = None,
    db: AsyncSession = Depends(get_db)
):
    """Upload and process document"""
    # Validate file type
    file_suffix = Path(file.filename).suffix.lower()
    if file_suffix not in settings.SUPPORTED_FORMATS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format. Supported: {settings.SUPPORTED_FORMATS}"
        )
    
    # Generate unique filename
    doc_id = str(uuid.uuid4())
    filename = f"{doc_id}{file_suffix}"
    file_path = settings.RAG_STORAGE_PATH / filename
    
    # Save file
    try:
        async with aiofiles.open(file_path, 'wb') as f:
            content = await file.read()
            await f.write(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save file: {str(e)}")
    
    # Create database record
    document = Document(
        filename=filename,
        original_filename=file.filename,
        file_path=str(file_path),
        file_type=file_suffix,
        file_size_bytes=len(content),
        title=title or file.filename,
        description=description,
        nfs_share_id=nfs_share_id,
        processing_status="pending",
        uploaded_by="system"  # TODO: Add auth
    )
    
    db.add(document)
    await db.commit()
    await db.refresh(document)
    
    # Process document in background
    if background_tasks:
        background_tasks.add_task(process_document_task, document.id, str(file_path))
    
    return DocumentUploadResponse(
        id=document.id,
        filename=document.original_filename,
        file_size_bytes=document.file_size_bytes,
        processing_status=document.processing_status,
        message="Document uploaded successfully. Processing in background."
    )


async def process_document_task(document_id: int, file_path: str):
    """Background task to process document"""
    from sqlalchemy.ext.asyncio import AsyncSession
    from models import AsyncSessionLocal
    
    async with AsyncSessionLocal() as db:
        # Get document
        result = await db.execute(select(Document).where(Document.id == document_id))
        document = result.scalar_one_or_none()
        
        if not document:
            return
        
        # Update status
        document.processing_status = "processing"
        await db.commit()
        
        try:
            # Process with RAG engine
            success, result = await rag_engine.process_document(
                file_path,
                str(document_id),
                metadata={
                    "filename": document.original_filename,
                    "title": document.title,
                    "document_id": document_id
                }
            )
            
            if success:
                document.processing_status = "completed"
                document.is_processed = True
                document.is_indexed = True
                document.chunk_count = result.get("chunks", 0)
                document.processed_at = datetime.now()
                document.embedding_model = settings.LOCAL_EMBEDDING_MODEL
            else:
                document.processing_status = "failed"
                document.error_message = result.get("error", "Unknown error")
            
            await db.commit()
            
        except Exception as e:
            document.processing_status = "failed"
            document.error_message = str(e)
            await db.commit()


@app.get("/api/v1/documents")
async def list_documents(
    skip: int = 0,
    limit: int = 100,
    nfs_share_id: Optional[int] = None,
    db: AsyncSession = Depends(get_db)
):
    """List all documents"""
    query = select(Document).offset(skip).limit(limit).order_by(Document.created_at.desc())
    
    if nfs_share_id is not None:
        query = query.where(Document.nfs_share_id == nfs_share_id)
    
    result = await db.execute(query)
    documents = result.scalars().all()
    
    return [
        {
            "id": doc.id,
            "filename": doc.original_filename,
            "title": doc.title,
            "file_type": doc.file_type,
            "file_size_bytes": doc.file_size_bytes,
            "processing_status": doc.processing_status,
            "is_indexed": doc.is_indexed,
            "chunk_count": doc.chunk_count,
            "created_at": doc.created_at.isoformat(),
            "nfs_share_id": doc.nfs_share_id
        }
        for doc in documents
    ]


@app.delete("/api/v1/documents/{document_id}")
async def delete_document(document_id: int, db: AsyncSession = Depends(get_db)):
    """Delete document"""
    result = await db.execute(select(Document).where(Document.id == document_id))
    document = result.scalar_one_or_none()
    
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    
    # Delete from vector store
    await rag_engine.delete_document(str(document_id))
    
    # Delete file
    file_path = Path(document.file_path)
    if file_path.exists():
        file_path.unlink()
    
    # Delete from database
    await db.delete(document)
    await db.commit()
    
    return {"message": "Document deleted successfully"}


@app.post("/api/v1/query", response_model=QueryResponse)
async def query_rag(
    query_req: QueryRequest,
    db: AsyncSession = Depends(get_db)
):
    """Query the RAG system"""
    try:
        # Execute query
        result = await rag_engine.query(
            query_req.query,
            top_k=query_req.top_k,
            use_llm=query_req.use_llm,
            llm_provider=query_req.llm_provider
        )
        
        # Log query
        query_log = QueryLog(
            query_text=query_req.query,
            llm_provider=query_req.llm_provider or settings.LLM_PROVIDER,
            llm_model=result.get("llm_metadata", {}).get("model"),
            response_text=result.get("response"),
            response_tokens=result.get("llm_metadata", {}).get("tokens"),
            retrieval_time_ms=result["retrieval_time_ms"],
            llm_time_ms=result.get("llm_time_ms"),
            total_time_ms=result["total_time_ms"],
            documents_retrieved=result["retrieved_documents"],
            retrieved_chunks=[doc["id"] for doc in result["documents"]],
            user_id="system"  # TODO: Add auth
        )
        
        db.add(query_log)
        await db.commit()
        
        return QueryResponse(**result)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/v1/query/history")
async def get_query_history(
    skip: int = 0,
    limit: int = 50,
    db: AsyncSession = Depends(get_db)
):
    """Get query history"""
    result = await db.execute(
        select(QueryLog)
        .offset(skip)
        .limit(limit)
        .order_by(QueryLog.created_at.desc())
    )
    queries = result.scalars().all()
    
    return [
        {
            "id": q.id,
            "query": q.query_text,
            "response": q.response_text[:200] + "..." if q.response_text and len(q.response_text) > 200 else q.response_text,
            "llm_provider": q.llm_provider,
            "documents_retrieved": q.documents_retrieved,
            "total_time_ms": q.total_time_ms,
            "created_at": q.created_at.isoformat()
        }
        for q in queries
    ]


# Add missing import
from sqlalchemy import func

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        workers=1 if settings.DEBUG else settings.WORKERS
    )
