"""
ZettaBrain Database Models
SQLAlchemy models for NFS management and RAG operations
"""
from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean, ForeignKey, JSON, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from datetime import datetime

Base = declarative_base()


class NFSShare(Base):
    """NFS Share configuration model"""
    __tablename__ = "nfs_shares"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), unique=True, nullable=False, index=True)
    path = Column(String(512), unique=True, nullable=False)
    client_spec = Column(String(255), nullable=False)  # IP or network range
    permissions = Column(String(50), default="rw,sync,no_subtree_check")
    is_active = Column(Boolean, default=True)
    description = Column(Text, nullable=True)
    
    # Metadata
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(100))
    
    # Usage statistics
    total_size_bytes = Column(Integer, default=0)
    file_count = Column(Integer, default=0)
    last_accessed = Column(DateTime(timezone=True))
    
    # Relationships
    documents = relationship("Document", back_populates="nfs_share", cascade="all, delete-orphan")


class Document(Base):
    """Document model for RAG system"""
    __tablename__ = "documents"
    
    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String(512), nullable=False)
    original_filename = Column(String(512), nullable=False)
    file_path = Column(String(1024), nullable=False)
    file_type = Column(String(50), nullable=False)
    file_size_bytes = Column(Integer, nullable=False)
    
    # NFS Association
    nfs_share_id = Column(Integer, ForeignKey("nfs_shares.id"), nullable=True)
    nfs_share = relationship("NFSShare", back_populates="documents")
    
    # Document metadata
    title = Column(String(512))
    author = Column(String(255))
    description = Column(Text)
    tags = Column(JSON, default=list)
    
    # Processing status
    is_processed = Column(Boolean, default=False)
    is_indexed = Column(Boolean, default=False)
    processing_status = Column(String(50), default="pending")  # pending, processing, completed, failed
    error_message = Column(Text, nullable=True)
    
    # Content
    text_content = Column(Text)
    page_count = Column(Integer)
    chunk_count = Column(Integer, default=0)
    
    # Embedding info
    embedding_model = Column(String(255))
    vector_db_id = Column(String(255), unique=True, index=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    processed_at = Column(DateTime(timezone=True))
    uploaded_by = Column(String(100))
    
    # Relationships
    chunks = relationship("DocumentChunk", back_populates="document", cascade="all, delete-orphan")
    queries = relationship("QueryLog", back_populates="document")


class DocumentChunk(Base):
    """Document chunks for vector search"""
    __tablename__ = "document_chunks"
    
    id = Column(Integer, primary_key=True, index=True)
    document_id = Column(Integer, ForeignKey("documents.id"), nullable=False)
    document = relationship("Document", back_populates="chunks")
    
    chunk_index = Column(Integer, nullable=False)
    chunk_text = Column(Text, nullable=False)
    chunk_size = Column(Integer, nullable=False)
    
    # Vector info
    vector_id = Column(String(255), unique=True, index=True)
    embedding_model = Column(String(255))
    
    # Metadata
    page_number = Column(Integer)
    section_title = Column(String(512))
    metadata = Column(JSON, default=dict)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class QueryLog(Base):
    """Query logs for RAG analytics"""
    __tablename__ = "query_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    query_text = Column(Text, nullable=False)
    query_embedding_model = Column(String(255))
    
    # Response
    llm_provider = Column(String(50))
    llm_model = Column(String(255))
    response_text = Column(Text)
    response_tokens = Column(Integer)
    
    # Performance
    retrieval_time_ms = Column(Float)
    llm_time_ms = Column(Float)
    total_time_ms = Column(Float)
    
    # Results
    documents_retrieved = Column(Integer)
    top_document_id = Column(Integer, ForeignKey("documents.id"))
    document = relationship("Document", back_populates="queries")
    retrieved_chunks = Column(JSON, default=list)
    
    # Context
    user_id = Column(String(100))
    session_id = Column(String(255))
    ip_address = Column(String(45))
    
    # Feedback
    feedback_rating = Column(Integer)  # 1-5 stars
    feedback_text = Column(Text)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class User(Base):
    """User model for authentication"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255))
    
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    last_login = Column(DateTime(timezone=True))


class SystemMetrics(Base):
    """System metrics for monitoring"""
    __tablename__ = "system_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Resource usage
    cpu_percent = Column(Float)
    memory_percent = Column(Float)
    disk_usage_percent = Column(Float)
    
    # NFS metrics
    nfs_shares_count = Column(Integer)
    nfs_total_size_gb = Column(Float)
    
    # RAG metrics
    documents_count = Column(Integer)
    indexed_documents_count = Column(Integer)
    total_chunks_count = Column(Integer)
    queries_count_today = Column(Integer)
    
    # Performance
    avg_query_time_ms = Column(Float)
    avg_retrieval_time_ms = Column(Float)
    
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)


# Database initialization
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from config import settings

engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,
    future=True
)

AsyncSessionLocal = sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False
)


async def get_db() -> AsyncSession:
    """Dependency for getting async database sessions"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


async def init_db():
    """Initialize database tables"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("Database initialized successfully")


if __name__ == "__main__":
    import asyncio
    asyncio.run(init_db())
