"""
ZettaBrain RAG Engine
Comprehensive RAG implementation with support for:
- Multiple LLM providers (local, Anthropic, OpenAI)
- Multiple vector databases (ChromaDB, FAISS, Pinecone, Qdrant, Weaviate)
- Document processing and chunking
- Semantic search and retrieval
"""
import asyncio
from typing import List, Dict, Optional, Tuple, Any
from pathlib import Path
import hashlib
from datetime import datetime
import time

# Document processing
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.document_loaders import (
    PyPDFLoader, Docx2txtLoader, TextLoader,
    UnstructuredPowerPointLoader, UnstructuredExcelLoader
)

# Embeddings
from sentence_transformers import SentenceTransformer
import torch
import numpy as np

# Vector Databases - Lightweight
import chromadb
from chromadb.config import Settings as ChromaSettings
import faiss

# Vector Databases - Production
try:
    from pinecone import Pinecone, ServerlessSpec
    PINECONE_AVAILABLE = True
except ImportError:
    PINECONE_AVAILABLE = False

try:
    from qdrant_client import QdrantClient
    from qdrant_client.models import Distance, VectorParams, PointStruct
    QDRANT_AVAILABLE = True
except ImportError:
    QDRANT_AVAILABLE = False

try:
    import weaviate
    WEAVIATE_AVAILABLE = True
except ImportError:
    WEAVIATE_AVAILABLE = False

# LLM integrations
try:
    from anthropic import AsyncAnthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

try:
    from openai import AsyncOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

from config import settings


class DocumentProcessor:
    """Process and chunk documents for RAG"""
    
    def __init__(self):
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.RAG_CHUNK_SIZE,
            chunk_overlap=settings.RAG_CHUNK_OVERLAP,
            length_function=len,
            separators=["\n\n", "\n", " ", ""]
        )
    
    async def load_document(self, file_path: str) -> Tuple[str, Dict]:
        """Load document and extract text"""
        path = Path(file_path)
        suffix = path.suffix.lower()
        
        try:
            if suffix == '.pdf':
                loader = PyPDFLoader(file_path)
                pages = loader.load()
                text = "\n\n".join([p.page_content for p in pages])
                metadata = {"page_count": len(pages)}
                
            elif suffix in ['.docx', '.doc']:
                loader = Docx2txtLoader(file_path)
                docs = loader.load()
                text = "\n\n".join([d.page_content for d in docs])
                metadata = {"page_count": 1}
                
            elif suffix in ['.txt', '.md']:
                loader = TextLoader(file_path)
                docs = loader.load()
                text = docs[0].page_content if docs else ""
                metadata = {"page_count": 1}
                
            elif suffix in ['.pptx', '.ppt']:
                loader = UnstructuredPowerPointLoader(file_path)
                docs = loader.load()
                text = "\n\n".join([d.page_content for d in docs])
                metadata = {"page_count": len(docs)}
                
            elif suffix in ['.xlsx', '.xls', '.csv']:
                loader = UnstructuredExcelLoader(file_path)
                docs = loader.load()
                text = "\n\n".join([d.page_content for d in docs])
                metadata = {"page_count": 1}
                
            else:
                return "", {"error": f"Unsupported file type: {suffix}"}
            
            return text, metadata
            
        except Exception as e:
            return "", {"error": str(e)}
    
    def chunk_text(self, text: str) -> List[Dict]:
        """Split text into chunks"""
        chunks = self.text_splitter.split_text(text)
        return [
            {
                "text": chunk,
                "index": idx,
                "size": len(chunk)
            }
            for idx, chunk in enumerate(chunks)
        ]


class EmbeddingEngine:
    """Generate embeddings using various models"""
    
    def __init__(self, model_name: Optional[str] = None):
        self.model_name = model_name or settings.LOCAL_EMBEDDING_MODEL
        self.model = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
    
    def load_model(self):
        """Load embedding model"""
        if self.model is None:
            self.model = SentenceTransformer(self.model_name, device=self.device)
    
    def embed_text(self, text: str) -> np.ndarray:
        """Generate embedding for single text"""
        self.load_model()
        return self.model.encode(text, convert_to_numpy=True)
    
    def embed_batch(self, texts: List[str]) -> np.ndarray:
        """Generate embeddings for batch of texts"""
        self.load_model()
        return self.model.encode(texts, convert_to_numpy=True, show_progress_bar=True)
    
    def get_dimension(self) -> int:
        """Get embedding dimension"""
        self.load_model()
        return self.model.get_sentence_embedding_dimension()


class ChromaDBStore:
    """ChromaDB vector store (lightweight)"""
    
    def __init__(self):
        self.client = chromadb.PersistentClient(
            path=str(settings.CHROMA_PERSIST_DIR),
            settings=ChromaSettings(anonymized_telemetry=False)
        )
        self.collection_name = settings.CHROMA_COLLECTION_NAME
        self.collection = None
        self.embedding_engine = EmbeddingEngine()
    
    def get_or_create_collection(self):
        """Get or create collection"""
        if self.collection is None:
            self.collection = self.client.get_or_create_collection(
                name=self.collection_name,
                metadata={"description": "ZettaBrain document embeddings"}
            )
    
    async def add_documents(
        self,
        document_id: str,
        chunks: List[Dict],
        metadata: Dict
    ) -> List[str]:
        """Add document chunks to ChromaDB"""
        self.get_or_create_collection()
        
        texts = [chunk["text"] for chunk in chunks]
        embeddings = self.embedding_engine.embed_batch(texts)
        
        ids = [f"{document_id}_chunk_{i}" for i in range(len(chunks))]
        metadatas = [
            {
                **metadata,
                "chunk_index": chunk["index"],
                "chunk_size": chunk["size"],
                "document_id": document_id
            }
            for chunk in chunks
        ]
        
        self.collection.add(
            embeddings=embeddings.tolist(),
            documents=texts,
            ids=ids,
            metadatas=metadatas
        )
        
        return ids
    
    async def search(
        self,
        query: str,
        top_k: int = 5,
        filter_dict: Optional[Dict] = None
    ) -> List[Dict]:
        """Search for similar documents"""
        self.get_or_create_collection()
        
        query_embedding = self.embedding_engine.embed_text(query)
        
        results = self.collection.query(
            query_embeddings=[query_embedding.tolist()],
            n_results=top_k,
            where=filter_dict
        )
        
        return [
            {
                "id": results["ids"][0][i],
                "text": results["documents"][0][i],
                "metadata": results["metadatas"][0][i],
                "distance": results["distances"][0][i] if results["distances"] else None
            }
            for i in range(len(results["ids"][0]))
        ]
    
    async def delete_document(self, document_id: str):
        """Delete all chunks for a document"""
        self.get_or_create_collection()
        
        # Query to get all IDs for this document
        results = self.collection.get(
            where={"document_id": document_id}
        )
        
        if results["ids"]:
            self.collection.delete(ids=results["ids"])


class FAISSStore:
    """FAISS vector store (lightweight)"""
    
    def __init__(self):
        self.index_path = settings.FAISS_INDEX_PATH
        self.index = None
        self.doc_map = {}  # Maps index position to document info
        self.embedding_engine = EmbeddingEngine()
        self.dimension = self.embedding_engine.get_dimension()
        self._load_or_create_index()
    
    def _load_or_create_index(self):
        """Load existing index or create new one"""
        index_file = self.index_path / "index.faiss"
        map_file = self.index_path / "doc_map.npy"
        
        if index_file.exists() and map_file.exists():
            self.index = faiss.read_index(str(index_file))
            self.doc_map = np.load(str(map_file), allow_pickle=True).item()
        else:
            self.index = faiss.IndexFlatL2(self.dimension)
            self.index_path.mkdir(parents=True, exist_ok=True)
    
    def _save_index(self):
        """Save index and mapping to disk"""
        faiss.write_index(self.index, str(self.index_path / "index.faiss"))
        np.save(str(self.index_path / "doc_map.npy"), self.doc_map)
    
    async def add_documents(
        self,
        document_id: str,
        chunks: List[Dict],
        metadata: Dict
    ) -> List[str]:
        """Add document chunks to FAISS"""
        texts = [chunk["text"] for chunk in chunks]
        embeddings = self.embedding_engine.embed_batch(texts)
        
        start_idx = self.index.ntotal
        self.index.add(embeddings.astype('float32'))
        
        ids = []
        for i, chunk in enumerate(chunks):
            idx = start_idx + i
            chunk_id = f"{document_id}_chunk_{i}"
            self.doc_map[idx] = {
                "id": chunk_id,
                "text": chunk["text"],
                "metadata": {**metadata, "chunk_index": chunk["index"]},
                "document_id": document_id
            }
            ids.append(chunk_id)
        
        self._save_index()
        return ids
    
    async def search(
        self,
        query: str,
        top_k: int = 5,
        filter_dict: Optional[Dict] = None
    ) -> List[Dict]:
        """Search for similar documents"""
        query_embedding = self.embedding_engine.embed_text(query)
        query_vector = query_embedding.astype('float32').reshape(1, -1)
        
        distances, indices = self.index.search(query_vector, min(top_k, self.index.ntotal))
        
        results = []
        for i, idx in enumerate(indices[0]):
            if idx in self.doc_map:
                doc_info = self.doc_map[idx]
                if filter_dict is None or all(
                    doc_info["metadata"].get(k) == v for k, v in filter_dict.items()
                ):
                    results.append({
                        "id": doc_info["id"],
                        "text": doc_info["text"],
                        "metadata": doc_info["metadata"],
                        "distance": float(distances[0][i])
                    })
        
        return results[:top_k]
    
    async def delete_document(self, document_id: str):
        """Delete document (requires rebuilding index)"""
        # Remove from doc_map
        indices_to_keep = [
            idx for idx, info in self.doc_map.items()
            if info["document_id"] != document_id
        ]
        
        # Rebuild index without deleted documents
        if indices_to_keep:
            old_map = self.doc_map.copy()
            self.doc_map = {}
            self.index = faiss.IndexFlatL2(self.dimension)
            
            # Re-add remaining documents
            for old_idx in indices_to_keep:
                info = old_map[old_idx]
                embedding = self.embedding_engine.embed_text(info["text"])
                new_idx = self.index.ntotal
                self.index.add(embedding.astype('float32').reshape(1, -1))
                self.doc_map[new_idx] = info
            
            self._save_index()


class LLMEngine:
    """LLM engine supporting multiple providers"""
    
    def __init__(self, provider: Optional[str] = None):
        self.provider = provider or settings.LLM_PROVIDER
        self.client = None
    
    async def generate_response(
        self,
        query: str,
        context: List[str],
        max_tokens: Optional[int] = None
    ) -> Tuple[str, Dict]:
        """Generate response using appropriate LLM"""
        
        # Build prompt
        context_text = "\n\n".join([f"Context {i+1}:\n{ctx}" for i, ctx in enumerate(context)])
        
        prompt = f"""Based on the following context, please answer the question.

{context_text}

Question: {query}

Answer:"""
        
        start_time = time.time()
        
        if self.provider == "anthropic":
            response, metadata = await self._anthropic_generate(prompt, max_tokens)
        elif self.provider == "openai":
            response, metadata = await self._openai_generate(prompt, max_tokens)
        else:
            response, metadata = await self._local_generate(prompt, max_tokens)
        
        metadata["generation_time_ms"] = (time.time() - start_time) * 1000
        return response, metadata
    
    async def _anthropic_generate(self, prompt: str, max_tokens: Optional[int]) -> Tuple[str, Dict]:
        """Generate using Anthropic Claude"""
        if not ANTHROPIC_AVAILABLE or not settings.ANTHROPIC_API_KEY:
            return "Anthropic API not configured", {"error": "API not available"}
        
        if self.client is None:
            self.client = AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
        
        max_tokens = max_tokens or settings.ANTHROPIC_MAX_TOKENS
        
        try:
            response = await self.client.messages.create(
                model=settings.ANTHROPIC_MODEL,
                max_tokens=max_tokens,
                messages=[{"role": "user", "content": prompt}]
            )
            
            return response.content[0].text, {
                "model": settings.ANTHROPIC_MODEL,
                "tokens": response.usage.output_tokens,
                "provider": "anthropic"
            }
        except Exception as e:
            return f"Error: {str(e)}", {"error": str(e)}
    
    async def _openai_generate(self, prompt: str, max_tokens: Optional[int]) -> Tuple[str, Dict]:
        """Generate using OpenAI"""
        if not OPENAI_AVAILABLE or not settings.OPENAI_API_KEY:
            return "OpenAI API not configured", {"error": "API not available"}
        
        if self.client is None:
            self.client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        
        max_tokens = max_tokens or settings.OPENAI_MAX_TOKENS
        
        try:
            response = await self.client.chat.completions.create(
                model=settings.OPENAI_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=max_tokens
            )
            
            return response.choices[0].message.content, {
                "model": settings.OPENAI_MODEL,
                "tokens": response.usage.completion_tokens,
                "provider": "openai"
            }
        except Exception as e:
            return f"Error: {str(e)}", {"error": str(e)}
    
    async def _local_generate(self, prompt: str, max_tokens: Optional[int]) -> Tuple[str, Dict]:
        """Generate using local model"""
        try:
            if self.client is None:
                tokenizer = AutoTokenizer.from_pretrained(settings.LOCAL_LLM_MODEL)
                model = AutoModelForSeq2SeqLM.from_pretrained(settings.LOCAL_LLM_MODEL)
                device = "cuda" if torch.cuda.is_available() else "cpu"
                model = model.to(device)
                self.client = (tokenizer, model, device)
            
            tokenizer, model, device = self.client
            
            inputs = tokenizer(prompt, return_tensors="pt", max_length=512, truncation=True)
            inputs = {k: v.to(device) for k, v in inputs.items()}
            
            max_length = max_tokens or 256
            outputs = model.generate(**inputs, max_length=max_length)
            response = tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            return response, {
                "model": settings.LOCAL_LLM_MODEL,
                "tokens": len(outputs[0]),
                "provider": "local"
            }
        except Exception as e:
            return f"Error: {str(e)}", {"error": str(e)}


class RAGEngine:
    """Main RAG engine orchestrating all components"""
    
    def __init__(self):
        self.doc_processor = DocumentProcessor()
        self.vector_store = None
        self.llm_engine = LLMEngine()
        self._init_vector_store()
    
    def _init_vector_store(self):
        """Initialize vector store based on configuration"""
        if settings.VECTOR_DB_TYPE == "chroma":
            self.vector_store = ChromaDBStore()
        elif settings.VECTOR_DB_TYPE == "faiss":
            self.vector_store = FAISSStore()
        # Add Pinecone, Qdrant, Weaviate initialization here
    
    async def process_document(
        self,
        file_path: str,
        document_id: str,
        metadata: Optional[Dict] = None
    ) -> Tuple[bool, Dict]:
        """Process document and add to vector store"""
        try:
            # Load document
            text, doc_metadata = await self.doc_processor.load_document(file_path)
            if not text:
                return False, {"error": doc_metadata.get("error", "No text extracted")}
            
            # Chunk text
            chunks = self.doc_processor.chunk_text(text)
            if not chunks:
                return False, {"error": "No chunks generated"}
            
            # Add metadata
            full_metadata = {**(metadata or {}), **doc_metadata}
            
            # Add to vector store
            chunk_ids = await self.vector_store.add_documents(
                document_id,
                chunks,
                full_metadata
            )
            
            return True, {
                "chunks": len(chunks),
                "chunk_ids": chunk_ids,
                "text_length": len(text)
            }
            
        except Exception as e:
            return False, {"error": str(e)}
    
    async def query(
        self,
        query_text: str,
        top_k: Optional[int] = None,
        use_llm: bool = True,
        llm_provider: Optional[str] = None
    ) -> Dict:
        """
        Query the RAG system
        
        Returns:
            Dict with retrieved documents and generated response
        """
        start_time = time.time()
        
        # Retrieve relevant documents
        retrieval_start = time.time()
        k = top_k or settings.RAG_TOP_K
        results = await self.vector_store.search(query_text, top_k=k)
        retrieval_time = (time.time() - retrieval_start) * 1000
        
        response_data = {
            "query": query_text,
            "retrieved_documents": len(results),
            "documents": results,
            "retrieval_time_ms": retrieval_time
        }
        
        # Generate response with LLM if requested
        if use_llm and results:
            context = [doc["text"] for doc in results]
            
            # Temporarily switch LLM provider if specified
            original_provider = self.llm_engine.provider
            if llm_provider:
                self.llm_engine.provider = llm_provider
            
            llm_response, llm_metadata = await self.llm_engine.generate_response(
                query_text,
                context
            )
            
            # Restore original provider
            self.llm_engine.provider = original_provider
            
            response_data.update({
                "response": llm_response,
                "llm_metadata": llm_metadata,
                "llm_time_ms": llm_metadata.get("generation_time_ms", 0)
            })
        
        response_data["total_time_ms"] = (time.time() - start_time) * 1000
        return response_data
    
    async def delete_document(self, document_id: str) -> bool:
        """Delete document from vector store"""
        try:
            await self.vector_store.delete_document(document_id)
            return True
        except Exception as e:
            print(f"Error deleting document: {e}")
            return False


# Global RAG engine instance
rag_engine = RAGEngine()
