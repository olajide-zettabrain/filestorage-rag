"""
ZettaBrain NFS-RAG Configuration Module
Manages all configuration settings for the application
"""
from pydantic_settings import BaseSettings
from typing import Optional, Literal
from pathlib import Path


class Settings(BaseSettings):
    """Application settings with environment variable support"""
    
    # Application
    APP_NAME: str = "ZettaBrain NFS-RAG Platform"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    API_V1_PREFIX: str = "/api/v1"
    
    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    WORKERS: int = 4
    
    # Security
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    ALLOWED_ORIGINS: list[str] = ["http://localhost:3000", "http://localhost:5173"]
    
    # Database
    DATABASE_URL: str = "postgresql+asyncpg://user:password@localhost:5432/zettabrain"
    POSTGRES_USER: str = "zettabrain"
    POSTGRES_PASSWORD: str = "zettabrain_password"
    POSTGRES_DB: str = "zettabrain"
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    
    # NFS Configuration
    NFS_BASE_PATH: Path = Path("/mnt/nfs")
    NFS_EXPORTS_FILE: Path = Path("/etc/exports")
    NFS_SERVICE_NAME: str = "nfs-server"
    
    # RAG Configuration
    RAG_STORAGE_PATH: Path = Path("/mnt/nfs/rag_documents")
    RAG_CHUNK_SIZE: int = 512
    RAG_CHUNK_OVERLAP: int = 50
    RAG_TOP_K: int = 5
    
    # Vector Database Settings
    VECTOR_DB_TYPE: Literal["chroma", "faiss", "pinecone", "qdrant", "weaviate"] = "chroma"
    
    # ChromaDB (Lightweight)
    CHROMA_PERSIST_DIR: Path = Path("/mnt/nfs/vector_db/chroma")
    CHROMA_COLLECTION_NAME: str = "zettabrain_docs"
    
    # FAISS (Lightweight)
    FAISS_INDEX_PATH: Path = Path("/mnt/nfs/vector_db/faiss")
    
    # Pinecone (Production)
    PINECONE_API_KEY: Optional[str] = None
    PINECONE_ENVIRONMENT: Optional[str] = None
    PINECONE_INDEX_NAME: str = "zettabrain"
    
    # Qdrant (Production)
    QDRANT_URL: Optional[str] = None
    QDRANT_API_KEY: Optional[str] = None
    QDRANT_COLLECTION_NAME: str = "zettabrain_docs"
    
    # Weaviate (Production)
    WEAVIATE_URL: Optional[str] = None
    WEAVIATE_API_KEY: Optional[str] = None
    WEAVIATE_CLASS_NAME: str = "ZettaBrainDoc"
    
    # LLM Settings
    LLM_PROVIDER: Literal["local", "anthropic", "openai"] = "local"
    
    # Local LLM (Lightweight)
    LOCAL_MODEL_NAME: str = "sentence-transformers/all-MiniLM-L6-v2"
    LOCAL_EMBEDDING_MODEL: str = "sentence-transformers/all-MiniLM-L6-v2"
    LOCAL_LLM_MODEL: str = "google/flan-t5-base"
    
    # Anthropic (Production)
    ANTHROPIC_API_KEY: Optional[str] = None
    ANTHROPIC_MODEL: str = "claude-sonnet-4-20250514"
    ANTHROPIC_MAX_TOKENS: int = 4096
    
    # OpenAI (Production)
    OPENAI_API_KEY: Optional[str] = None
    OPENAI_MODEL: str = "gpt-4-turbo-preview"
    OPENAI_EMBEDDING_MODEL: str = "text-embedding-3-small"
    OPENAI_MAX_TOKENS: int = 4096
    
    # Document Processing
    MAX_UPLOAD_SIZE: int = 100 * 1024 * 1024  # 100MB
    SUPPORTED_FORMATS: list[str] = [
        ".pdf", ".docx", ".doc", ".txt", ".md",
        ".pptx", ".ppt", ".xlsx", ".xls", ".csv"
    ]
    
    # Monitoring
    ENABLE_METRICS: bool = True
    METRICS_PORT: int = 9090
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "json"
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()


# Ensure required directories exist
def init_directories():
    """Create necessary directories if they don't exist"""
    directories = [
        settings.NFS_BASE_PATH,
        settings.RAG_STORAGE_PATH,
        settings.CHROMA_PERSIST_DIR,
        settings.FAISS_INDEX_PATH,
    ]
    
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)
        print(f"Ensured directory exists: {directory}")


if __name__ == "__main__":
    init_directories()
    print("Configuration initialized successfully")
    print(f"App Name: {settings.APP_NAME}")
    print(f"Vector DB: {settings.VECTOR_DB_TYPE}")
    print(f"LLM Provider: {settings.LLM_PROVIDER}")
