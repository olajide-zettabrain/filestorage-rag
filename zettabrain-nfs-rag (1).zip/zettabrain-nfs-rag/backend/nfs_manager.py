"""
ZettaBrain NFS Manager
Handles all NFS server operations including share management, exports, and monitoring
"""
import asyncio
import subprocess
import os
import shutil
import re
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import psutil
from datetime import datetime

from config import settings


@dataclass
class NFSShareInfo:
    """NFS Share information"""
    name: str
    path: str
    client_spec: str
    permissions: str
    is_active: bool
    size_bytes: int = 0
    file_count: int = 0
    last_accessed: Optional[datetime] = None


class NFSManager:
    """
    NFS Server Management Class
    Handles NFS share creation, deletion, configuration, and monitoring
    """
    
    def __init__(self):
        self.exports_file = settings.NFS_EXPORTS_FILE
        self.nfs_base_path = settings.NFS_BASE_PATH
        self.service_name = settings.NFS_SERVICE_NAME
        
    async def _run_command(self, command: List[str]) -> Tuple[str, str, int]:
        """Execute shell command asynchronously"""
        try:
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            return stdout.decode(), stderr.decode(), process.returncode
        except Exception as e:
            return "", str(e), 1
    
    async def _run_sudo_command(self, command: List[str]) -> Tuple[str, str, int]:
        """Execute command with sudo privileges"""
        full_command = ["sudo"] + command
        return await self._run_command(full_command)
    
    async def check_nfs_server_installed(self) -> bool:
        """Check if NFS server is installed"""
        stdout, _, returncode = await self._run_command(["which", "exportfs"])
        return returncode == 0
    
    async def check_nfs_server_running(self) -> bool:
        """Check if NFS server service is running"""
        stdout, _, returncode = await self._run_sudo_command(
            ["systemctl", "is-active", self.service_name]
        )
        return stdout.strip() == "active"
    
    async def start_nfs_server(self) -> bool:
        """Start NFS server service"""
        _, stderr, returncode = await self._run_sudo_command(
            ["systemctl", "start", self.service_name]
        )
        if returncode == 0:
            await self._run_sudo_command(["systemctl", "enable", self.service_name])
            return True
        return False
    
    async def stop_nfs_server(self) -> bool:
        """Stop NFS server service"""
        _, stderr, returncode = await self._run_sudo_command(
            ["systemctl", "stop", self.service_name]
        )
        return returncode == 0
    
    async def restart_nfs_server(self) -> bool:
        """Restart NFS server service"""
        _, stderr, returncode = await self._run_sudo_command(
            ["systemctl", "restart", self.service_name]
        )
        return returncode == 0
    
    async def get_nfs_server_status(self) -> Dict:
        """Get detailed NFS server status"""
        is_running = await self.check_nfs_server_running()
        
        # Get service details
        stdout, _, _ = await self._run_sudo_command(
            ["systemctl", "status", self.service_name]
        )
        
        # Count active connections
        conn_stdout, _, _ = await self._run_sudo_command(["showmount", "-a"])
        active_connections = len([line for line in conn_stdout.split('\n') if line.strip()])
        
        return {
            "is_running": is_running,
            "service_name": self.service_name,
            "active_connections": max(0, active_connections - 1),  # Subtract header
            "status_output": stdout,
            "timestamp": datetime.now().isoformat()
        }
    
    def _parse_exports_file(self) -> List[Dict]:
        """Parse /etc/exports file"""
        exports = []
        try:
            if not self.exports_file.exists():
                return exports
                
            with open(self.exports_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    # Parse export line: /path client(options)
                    match = re.match(r'(\S+)\s+(\S+)\(([^)]+)\)', line)
                    if match:
                        path, client, options = match.groups()
                        exports.append({
                            "path": path,
                            "client": client,
                            "options": options
                        })
        except Exception as e:
            print(f"Error parsing exports file: {e}")
        
        return exports
    
    async def list_shares(self) -> List[Dict]:
        """List all NFS shares"""
        exports = self._parse_exports_file()
        shares = []
        
        for export in exports:
            path = Path(export["path"])
            size_bytes = 0
            file_count = 0
            
            if path.exists():
                size_bytes = await self._get_directory_size(path)
                file_count = await self._count_files(path)
            
            shares.append({
                "path": export["path"],
                "client": export["client"],
                "permissions": export["options"],
                "exists": path.exists(),
                "size_bytes": size_bytes,
                "file_count": file_count
            })
        
        return shares
    
    async def _get_directory_size(self, path: Path) -> int:
        """Calculate total size of directory"""
        try:
            total_size = 0
            for dirpath, dirnames, filenames in os.walk(path):
                for filename in filenames:
                    filepath = os.path.join(dirpath, filename)
                    if os.path.exists(filepath):
                        total_size += os.path.getsize(filepath)
            return total_size
        except Exception as e:
            print(f"Error calculating directory size: {e}")
            return 0
    
    async def _count_files(self, path: Path) -> int:
        """Count total files in directory"""
        try:
            count = 0
            for dirpath, dirnames, filenames in os.walk(path):
                count += len(filenames)
            return count
        except Exception:
            return 0
    
    async def create_share(
        self,
        path: str,
        client_spec: str = "*",
        permissions: str = "rw,sync,no_subtree_check"
    ) -> Tuple[bool, str]:
        """
        Create a new NFS share
        
        Args:
            path: Directory path to share
            client_spec: Client specification (IP, network, or *)
            permissions: NFS permissions
        
        Returns:
            Tuple of (success, message)
        """
        share_path = Path(path)
        
        # Create directory if it doesn't exist
        try:
            share_path.mkdir(parents=True, exist_ok=True)
            os.chmod(share_path, 0o755)
        except Exception as e:
            return False, f"Failed to create directory: {e}"
        
        # Check if share already exists
        exports = self._parse_exports_file()
        for export in exports:
            if export["path"] == str(share_path):
                return False, "Share already exists"
        
        # Add to exports file
        export_line = f"{share_path} {client_spec}({permissions})\n"
        try:
            with open(self.exports_file, 'a') as f:
                f.write(export_line)
        except Exception as e:
            return False, f"Failed to update exports file: {e}"
        
        # Apply changes
        _, stderr, returncode = await self._run_sudo_command(["exportfs", "-ra"])
        if returncode != 0:
            return False, f"Failed to export share: {stderr}"
        
        return True, "Share created successfully"
    
    async def remove_share(self, path: str, delete_data: bool = False) -> Tuple[bool, str]:
        """
        Remove an NFS share
        
        Args:
            path: Directory path to unshare
            delete_data: Whether to delete the actual data
        
        Returns:
            Tuple of (success, message)
        """
        share_path = Path(path)
        
        # Read exports file
        try:
            with open(self.exports_file, 'r') as f:
                lines = f.readlines()
        except Exception as e:
            return False, f"Failed to read exports file: {e}"
        
        # Remove the export line
        new_lines = []
        found = False
        for line in lines:
            if not line.strip().startswith(str(share_path)):
                new_lines.append(line)
            else:
                found = True
        
        if not found:
            return False, "Share not found in exports"
        
        # Write back
        try:
            with open(self.exports_file, 'w') as f:
                f.writelines(new_lines)
        except Exception as e:
            return False, f"Failed to update exports file: {e}"
        
        # Apply changes
        _, stderr, returncode = await self._run_sudo_command(["exportfs", "-ra"])
        if returncode != 0:
            return False, f"Failed to unexport share: {stderr}"
        
        # Optionally delete data
        if delete_data and share_path.exists():
            try:
                shutil.rmtree(share_path)
            except Exception as e:
                return True, f"Share removed but failed to delete data: {e}"
        
        return True, "Share removed successfully"
    
    async def update_share(
        self,
        path: str,
        client_spec: Optional[str] = None,
        permissions: Optional[str] = None
    ) -> Tuple[bool, str]:
        """Update an existing NFS share"""
        # Remove and recreate
        success, msg = await self.remove_share(path, delete_data=False)
        if not success:
            return False, msg
        
        new_client = client_spec if client_spec else "*"
        new_perms = permissions if permissions else "rw,sync,no_subtree_check"
        
        return await self.create_share(path, new_client, new_perms)
    
    async def get_system_stats(self) -> Dict:
        """Get system resource statistics"""
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage(str(self.nfs_base_path))
        
        return {
            "cpu_percent": cpu_percent,
            "memory_percent": memory.percent,
            "memory_used_gb": memory.used / (1024**3),
            "memory_total_gb": memory.total / (1024**3),
            "disk_percent": disk.percent,
            "disk_used_gb": disk.used / (1024**3),
            "disk_total_gb": disk.total / (1024**3),
            "disk_free_gb": disk.free / (1024**3),
        }
    
    async def get_mounted_clients(self) -> List[Dict]:
        """Get list of currently mounted NFS clients"""
        stdout, _, returncode = await self._run_sudo_command(["showmount", "-a"])
        
        clients = []
        if returncode == 0:
            for line in stdout.split('\n')[1:]:  # Skip header
                if line.strip():
                    parts = line.strip().split(':')
                    if len(parts) == 2:
                        clients.append({
                            "hostname": parts[0],
                            "mount_point": parts[1]
                        })
        
        return clients


# Global instance
nfs_manager = NFSManager()
